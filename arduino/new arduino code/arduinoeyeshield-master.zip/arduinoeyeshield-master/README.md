Example code for the Arduino Eye Shield - http://davidchatting.com/arduinoeyeshield/
